#include "gui.h"
#include "../../../inc/glbtypes.h"
#include "../../../inc/scl.h"

//#include "../../src/sclproc.c"

#include<stdio.h>
#include<string.h>

extern ST_BOOLEAN *SvEnaPtr;
extern ST_UCHAR *MsvIDPtr;
extern ST_UINT32 *ConfRevPtr;
extern ST_UCHAR *DatSetPtr;
extern ST_INT8 *SmpModPtr;
extern ST_UINT16 *SmpRatePtr;

extern SCL_SVCB *scl_svcb;
/*
extern SCL_SERVER *scl_server;
extern SCL_LD *scl_ld;
extern SCL_LN *scl_ln;
*/
void *MU_GUI(void *data)
{
  //GtkWidget *window, *fixed, *combo_box, *table, *attr[10], *value[10];
//  GtkWidget *window, *fixed, *combo_box, *table, *attr[9];
   extern change *changePTR;
	 extern GtkWidget *value[9], *window, *fixed, *combo_box, *table, *attr[9], *btn[4];
  int i=0;

  /* Initialize GTK */
  gtk_init(NULL,NULL);

  /* Create a new window */
  window = gtk_window_new (GTK_WINDOW_TOPLEVEL);
  gtk_widget_set_size_request(window,350,400);
  gtk_window_set_resizable(GTK_WINDOW(window),FALSE);
  gtk_window_set_title (GTK_WINDOW (window), "MU_Control");
  gtk_window_position  (GTK_WINDOW(window), GTK_WIN_POS_CENTER);


  /* Conect the "destroy" event to a signal handler*/
  g_signal_connect (window, "destroy", G_CALLBACK (destroy), NULL);
  g_signal_connect (window, "delete_event", G_CALLBACK (delete_event), NULL);

  /* Sets the border width of the window. */
  gtk_container_set_border_width (GTK_CONTAINER (window), 10);

  /* Create a fixed container */
  fixed = gtk_fixed_new();
  gtk_container_add(GTK_CONTAINER (window), fixed);
  gtk_widget_show (fixed);

  /* Create a Combo_box */
  combo_box = gtk_combo_box_new_text();

  /* Set the combo_box item */
  gtk_combo_box_append_text(GTK_COMBO_BOX(combo_box),"MSVCB01");
  gtk_combo_box_append_text(GTK_COMBO_BOX(combo_box),"MSVCB02");
/* Set the first item-active */
  gtk_combo_box_set_active(GTK_COMBO_BOX(combo_box),0);

  /* Add Combo_box to fixed container */
  gtk_fixed_put(GTK_FIXED (fixed), combo_box,0,0);

  /* Create a table */
  table = gtk_table_new(10,2,TRUE);

  /* Create a label(attr)*/
  attr[0]=gtk_label_new("MsvCBRef(disable)");
  attr[1]=gtk_label_new("*SvEna (0 or 1)");
  attr[2]=gtk_label_new("*MsvID");
  attr[3]=gtk_label_new("*DatSet");
  attr[4]=gtk_label_new("*ConfRev");
  attr[5]=gtk_label_new("*SmpMod (0 or 1 or 2)");
  attr[6]=gtk_label_new("*SmpRate");
  attr[7]=gtk_label_new("OptFlds(disable)");
  attr[8]=gtk_label_new("DstAddress(disable)");

  /* Create a entry(value)*/
  for(i=0;i<9;i++)
  {
    value[i]=gtk_entry_new();
    gtk_entry_set_alignment(GTK_ENTRY(value[i]),0.5);
  }


  char ttmpSvEna[2];
	char ttmpConfRev[10];
	char ttmpSmpMod[2];
	char ttmpSmpRate[10];
	char ttmpSmvID[20];
	char ttmpDatSet[32];

		getdata(ttmpSvEna, ttmpConfRev, ttmpSmpMod, ttmpSmpRate, ttmpSmvID, ttmpDatSet);

    gtk_entry_set_text(GTK_ENTRY(value[0]),"-");
    gtk_entry_set_text(GTK_ENTRY(value[1]),ttmpSvEna);
    gtk_entry_set_text(GTK_ENTRY(value[2]),ttmpSmvID);
    gtk_entry_set_text(GTK_ENTRY(value[3]),ttmpDatSet);
    gtk_entry_set_text(GTK_ENTRY(value[4]),ttmpConfRev);
    gtk_entry_set_text(GTK_ENTRY(value[5]),ttmpSmpMod);
    gtk_entry_set_text(GTK_ENTRY(value[6]),ttmpSmpRate);
    gtk_entry_set_text(GTK_ENTRY(value[7]),"-");
    gtk_entry_set_text(GTK_ENTRY(value[8]),"-");
/*
    gtk_entry_set_text(GTK_ENTRY(value[0]),"-");
    gtk_entry_set_text(GTK_ENTRY(value[1]),"1");
    gtk_entry_set_text(GTK_ENTRY(value[2]),"TESTMU0101");
    gtk_entry_set_text(GTK_ENTRY(value[3]),"MU1MU01/LLN0$PhsMeas1");
    gtk_entry_set_text(GTK_ENTRY(value[4]),"1");
    gtk_entry_set_text(GTK_ENTRY(value[5]),"0");
    gtk_entry_set_text(GTK_ENTRY(value[6]),"80");
    gtk_entry_set_text(GTK_ENTRY(value[7]),"-");
    gtk_entry_set_text(GTK_ENTRY(value[8]),"-");
*/

    gtk_entry_set_editable(GTK_ENTRY(value[0]),FALSE);
    gtk_entry_set_editable(GTK_ENTRY(value[7]),FALSE);
    gtk_entry_set_editable(GTK_ENTRY(value[8]),FALSE);

 /* Attach the label(attr) and entry(value) widget to their parent container(table)  */

  for(i=0;i<9;i++)
  {
    gtk_table_attach(GTK_TABLE(table),attr[i],0,1,i,i+1,GTK_EXPAND,GTK_SHRINK,0,0);
    gtk_table_attach(GTK_TABLE(table),value[i],1,2,i,i+1,GTK_EXPAND,GTK_SHRINK,0,0);
  }

  /* Add 5 pixels of spacing between every row and every column */
  gtk_table_set_row_spacings(GTK_TABLE(table),5);
  gtk_table_set_col_spacings(GTK_TABLE(table),5);

  /* Add Combo_box to fixed container */
  gtk_fixed_put(GTK_FIXED (fixed), table,0,40);

  /* Create a button */
  btn[0]=gtk_button_new_with_label("refresh");
  btn[1]=gtk_button_new_with_label("APPLY");

  /* Add buttons to fixed container */
  gtk_fixed_put(GTK_FIXED (fixed), btn[0],200,340);
  gtk_fixed_put(GTK_FIXED (fixed), btn[1],270,340);

  /*Create a change structure and allocate window , value(entry), combo_box */
  changePTR = g_new(change,1);
  changePTR -> window = (GtkWidget *) window;
  changePTR -> value = (GtkEntry**) value;
  changePTR -> combo_box = (GtkWidget *) combo_box;

  /* Conect the "clicked" event to a signal handler*/
  g_signal_connect (G_OBJECT(btn[0]), "clicked", G_CALLBACK(refresh_value),(gpointer)value);
  g_signal_connect (G_OBJECT(btn[1]), "clicked", G_CALLBACK(check_value),changePTR);

  /* Display the window */
  gtk_widget_show_all(window);

  /* Enter the event loop */
  gtk_main();

  return 0;
}
void refresh_value(GtkEntry *Entry, gpointer data)
{

  GtkEntry **entry = (GtkEntry**)data;
  int k;
  char tmpSvEna[2];
  char tmpConfRev[10];
  char tmpSmpMod[2];
  char tmpSmpRate[10];
	char tmpSmvID[20];
	char tmpDatSet[32];

getdata(tmpSvEna, tmpConfRev, tmpSmpMod, tmpSmpRate, tmpSmvID, tmpDatSet);


//	getdata(tmpSvEna,tmpConfRev,tmpSmpMod,tmpSmpRate);
/*
  //snprintf( NULL, 0, "%lu", *ConfRevPtr);
  snprintf( tmpConfRev, 10, "%lu", *ConfRevPtr);

  //snprintf( NULL, 0, "%lu", *SvEnaPtr); 
  snprintf( tmpSvEna, 2, "%lu", *SvEnaPtr);

  snprintf( tmpSmpMod, 2, "%x", *SmpModPtr);
  //strcpy(tmpSmpMod,SmpModPtr);
  snprintf( tmpSmpRate, 10, "%hu", *SmpRatePtr);
*/

  gtk_entry_set_text(GTK_ENTRY(value[0]),"-");
  gtk_entry_set_text(GTK_ENTRY(value[1]),tmpSvEna);
  gtk_entry_set_text(GTK_ENTRY(value[2]),MsvIDPtr);
  gtk_entry_set_text(GTK_ENTRY(value[3]),DatSetPtr);
  gtk_entry_set_text(GTK_ENTRY(value[4]),tmpConfRev);
  gtk_entry_set_text(GTK_ENTRY(value[5]),tmpSmpMod);
  gtk_entry_set_text(GTK_ENTRY(value[6]),tmpSmpRate);
  gtk_entry_set_text(GTK_ENTRY(value[7]),"-");
  gtk_entry_set_text(GTK_ENTRY(value[8]),"-");


}
void check_value(GtkWidget *window, change *change)
{
  GtkWidget *w = change->window;
  GtkEntry **entry = change->value;
  GtkWidget *combo_box = change->combo_box;


  int k;
  int chk=1;
  char mode[8];

  int check0=1;
  int check1=1;
  int check2=1;

	//printf("you clicked check value\n");

  /* check empty value  */
  for(k=0;k<9;k++)
  {
    if(strcmp("",gtk_entry_get_text(GTK_ENTRY(entry[k])))==0)
    {
      show_error(window,change,10);
      chk=0;
      return;
    }
  }


  /*check SvEna value = it must have '1' or '0' */
  check1=strcmp("1",gtk_entry_get_text(GTK_ENTRY(entry[1])));
  check0=strcmp("0",gtk_entry_get_text(GTK_ENTRY(entry[1])));
  if(check1!=0&&check0!=0)
  {
    show_error(window,change,2);
    return ;
  }

  /* check smpMod value = it must have '0'or'1'or'2' */
  check0=strcmp("0",gtk_entry_get_text(GTK_ENTRY(entry[5])));
  check1=strcmp("1",gtk_entry_get_text(GTK_ENTRY(entry[5])));
  check2=strcmp("2",gtk_entry_get_text(GTK_ENTRY(entry[5])));
  if(check0!=0&&check1!=0&&check2!=0)
{
    show_error(window,change,6);
    return;
  }
 /* check SmpRate value = it must have number (not string) */
  if(!checkNum(gtk_entry_get_text(GTK_ENTRY(entry[6]))))
  {
    show_error(window,change,7);
    return;
  }

  else if(chk==1)
  {
    if(gtk_combo_box_get_active(GTK_COMBO_BOX(combo_box))==0)
    {

      strcpy(mode,"MSVCB01");
      //get_basic_CtrlData("MSVCB01", entry);
      apply_value("MSVCB01", entry);

    }else
    {
      strcpy(mode,"MSVCB02");
      //get_basic_CtrlData("MSVCB02",entry);
      apply_value("MSVCB02",entry);

    }
  }
  memset(mode,'\0',8);
}
/* Show error dialog */
void show_error(GtkWidget *window, change *change, int t)
{
  GtkWidget *w = change->window;
  GtkWidget *dialog;
  if(t==10)
  {
    dialog = gtk_message_dialog_new(GTK_WINDOW(w),GTK_DIALOG_DESTROY_WITH_PARENT, GTK_MESSAGE_ERROR,GTK_BUTTONS_OK, "Please fill in all values");
  }
  else if(t==2)
  {
    dialog = gtk_message_dialog_new(GTK_WINDOW(w),GTK_DIALOG_DESTROY_WITH_PARENT, GTK_MESSAGE_ERROR,GTK_BUTTONS_OK, "Please fill in SvEna 1 or 0");
  }
  else if(t==6)
  {
    dialog = gtk_message_dialog_new(GTK_WINDOW(w),GTK_DIALOG_DESTROY_WITH_PARENT, GTK_MESSAGE_ERROR,GTK_BUTTONS_OK, "Please fill in SmpMod 0 or 1 or 2");
  }
  else if(t==7)
  {
    dialog = gtk_message_dialog_new(GTK_WINDOW(w),GTK_DIALOG_DESTROY_WITH_PARENT, GTK_MESSAGE_ERROR,GTK_BUTTONS_OK, "Please fill in SmpRate number(Not String)");
  }

  gtk_window_set_title(GTK_WINDOW(dialog),"Error");
  gtk_dialog_run(GTK_DIALOG(dialog));
  gtk_widget_destroy(dialog);
}
int checkNum(const gchar *gtk_entry_get_text)
{
  int i;
  size_t size = strlen(gtk_entry_get_text);
  if(size==0)
    return 0;
  for(i=0;i<(int)size;i++)
  {
    if(gtk_entry_get_text[i] == '.' || gtk_entry_get_text[i] == '-' || gtk_entry_get_text[i] =='+')
      continue;
    if(gtk_entry_get_text[i] <'0' || gtk_entry_get_text[i]>'9')
      return 0;
  }
  return 1;
}
void destroy(GtkWidget *window, gpointer data)
{
    printf("Terminate Program\n");
    gtk_main_quit();
    exit(0);
}
/*Return FALSE to destroy the widget. By returning TRUE, you can cancel a delete-event. This can be used to confirm quitting the application*/
gboolean delete_event(GtkWidget *window , GdkEvent *evebt, gpointer data){
      return FALSE;
}
//void get_basic_CtrlData(char *MSVMODE, GtkWidget **entry)//get data set from memory( ex. SvEnaPtr, MSVCB01, etc..)
void apply_value(char *MSVMODE, GtkWidget **entry)//get data set from memory( ex. SvEnaPtr, MSVCB01, etc..)
{
  
  char *tmp1=(char*)malloc(16);
  char *tmp2=(char*)malloc(8);
  char *tmp3=(char*)malloc(32);
  char *tmp4=(char*)malloc(8);

//SvEnaPtr
  if(strcmp(gtk_entry_get_text(GTK_ENTRY(entry[1])),"0"))
    *SvEnaPtr=1;
  else
    *SvEnaPtr=0;

//SmpModPtr
  if(strcmp(gtk_entry_get_text(GTK_ENTRY(entry[5])),"0")==0)
  {
    *SmpModPtr=0;
    scl_svcb->smpMod=0;
  }
  else if (strcmp(gtk_entry_get_text(GTK_ENTRY(entry[5])),"1")==0)
  {
    *SmpModPtr=1;
    scl_svcb->smpMod=1;
  }
  else
  {
    *SmpModPtr=2;
    scl_svcb->smpMod=2;
  }
//SmpRatePtr
  strcpy(tmp2,gtk_entry_get_text(GTK_ENTRY(entry[6])));
  *SmpRatePtr=(ST_UINT16*)strtol(tmp2,NULL,0);
  scl_svcb->smpRate=*SmpRatePtr;
  free(tmp2);

//MsvIDPtr = ST_UCHAR-unsigned char
  strcpy(tmp1,gtk_entry_get_text(GTK_ENTRY(entry[2])));
  strcpy(MsvIDPtr,tmp1);
  strcpy(scl_svcb->smvID,tmp1);
  free(tmp1);

//DatSetPtr = ST_UCHAR-unsigned char
  strcpy(tmp3,gtk_entry_get_text(GTK_ENTRY(entry[3])));
  strcpy(DatSetPtr,tmp3);
  strcpy(scl_svcb->datSet,tmp3);
  free(tmp3);

//ConfRevPtr = ST_UINT32 - unsigned long
  strcpy(tmp4,gtk_entry_get_text(GTK_ENTRY(entry[4])));
	*ConfRevPtr=(ST_UINT32*)strtol(tmp4,NULL,0);
  scl_svcb->confRev=*ConfRevPtr;
  free(tmp4);
  
}
void getdata(char *tmpSvEna, char *tmpConfRev, char *tmpSmpMod, char *tmpSmpRate, char *tmpSmvID, char *tmpDatSet)
{

  //snprintf( NULL, 0, "%lu", *ConfRevPtr);
  snprintf( tmpConfRev, 10, "%lu", *ConfRevPtr);

  //snprintf( NULL, 0, "%lu", *SvEnaPtr); 
  snprintf( tmpSvEna, 2, "%lu", *SvEnaPtr);

  snprintf( tmpSmpMod, 2, "%x", *SmpModPtr);
  snprintf( tmpSmpRate, 10, "%hu", *SmpRatePtr);

	strcpy(tmpSmvID,MsvIDPtr);
	strcpy(tmpDatSet,DatSetPtr);

}

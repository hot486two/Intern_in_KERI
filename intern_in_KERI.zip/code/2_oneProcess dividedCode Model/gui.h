#include<gtk/gtk.h>
void *MU_GUI(void *data);
typedef struct{
	GtkWidget *window;
	GtkEntry **value;
	GtkWidget *combo_box;
} change;
change *changePTR;
GtkWidget *value[9], *window, *fixed, *combo_box, *table, *attr[9], *btn[4];
//void get_basic_CtrlData(char* MSVMODE, GtkWidget **entry);//get data set from memory( ex. SvEnaPtr, MSVCB01, etc..)
void destroy(GtkWidget*, gpointer);
gboolean delete_event(GtkWidget*, GdkEvent*, gpointer);

void refresh_value(GtkEntry*, gpointer);
void check_value(GtkWidget* ,change*);
void apply_value(char *MSVMODE, GtkWidget **entry);
void show_error(GtkWidget*, change*, int t);  
int checkNum(const gchar *gtk_entry_get_text);
void getdata(char *tmpSvEna, char *tmpConfRev, char *tmpSmpMod, char *tmpSmpRate, char *tmpSmvID, char *tmpDatSet);


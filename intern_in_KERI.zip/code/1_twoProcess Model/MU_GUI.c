#include<gtk/gtk.h>
#include<stdio.h>
#include<sys/ipc.h>
#include<sys/shm.h>

#define KEY_NUM 9527
#define MEM_SIZE 16


static void destroy(GtkWidget*, gpointer);
static gboolean delete_event(GtkWidget*, GdkEvent*, gpointer);

static void start_click(GtkButton*, gpointer);
static void stop_click(GtkButton*, gpointer);

/*For shared memory*/
int count=0;
int shm_id;
void *shm_addr;

int main (int argc, char *argv[])
{
	
	/* Start - shared memory setting */
	if(-1==(shm_id=shmget((key_t)KEY_NUM,MEM_SIZE,IPC_CREAT|0666)))
	{   
		printf("fail to make a shared memory\n");
		return -1; 
	}   

	if((void*)-1==(shm_addr=shmat(shm_id,(void*)0,0)))
	{   
		printf("fail to reference the shared memoey\n");
		return -1;
	}   
	sprintf((char *)shm_addr,"%d",count);
	/* End - Shared memory setting */


	/* For GUI-using gtk */
	int i=0;
	GtkWidget *window, *vbox;

	GtkWidget *buttons[2];
	buttons[0] = gtk_button_new_with_label("start");
	buttons[1] = gtk_button_new_with_label("stop");

	gtk_widget_set_sensitive ( (gpointer)buttons[1], FALSE);
	
	gtk_init(&argc,&argv);

	window = gtk_window_new (GTK_WINDOW_TOPLEVEL);
	gtk_window_set_title (GTK_WINDOW(window),"start/stop");
	gtk_container_set_border_width (GTK_CONTAINER(window),10);
	gtk_widget_set_size_request(window,200,100);

	/*Connect the main window to the destroy and delete-event signals*/
	g_signal_connect(G_OBJECT(window),"destroy",G_CALLBACK(destroy),NULL);
	g_signal_connect(G_OBJECT(window),"delete-event",G_CALLBACK(delete_event    ),NULL);

	vbox = gtk_vbox_new (TRUE,5);


	/*Connect the 'start' button to the 'clicked' signal and CALLBACK function-'start-click'
	 Connect the 'stop' button to the 'clicked' signal and CALLBACK function-'stop-click'
	 */
	g_signal_connect ( G_OBJECT ( buttons[0]), "clicked", G_CALLBACK( start_click), buttons);
	g_signal_connect ( G_OBJECT ( buttons[1]), "clicked", G_CALLBACK( stop_click),  buttons);

	gtk_box_pack_start_defaults (GTK_BOX(vbox), buttons[0]);
	gtk_box_pack_start_defaults (GTK_BOX(vbox), buttons[1]);

	gtk_container_add (GTK_CONTAINER(window),vbox);
	gtk_widget_show_all (window);

	gtk_main();
	return 0;
}


/*If you click 'start' button, 'start' button is 'grayed out' and the user can't interact with 'start' button and 'stop' button is 'active' and user can interact with 'stop button*/
static void start_click(GtkButton *button, gpointer data)
{
	sprintf((char *)shm_addr,"%d",1);

	GtkWidget **temp = data;
	gtk_widget_set_sensitive (temp[1],TRUE);
	gtk_widget_set_sensitive (temp[0],FALSE);

	printf("start\n");


}


/*If you click 'stop' button, 'stop' button is 'grayed out' and the user can't interact with 'stop' button and 'start' button is 'active' and user can interact with 'start' button*/
static void stop_click(GtkButton *button, gpointer data)
{

	sprintf((char *)shm_addr,"%d",0);

	GtkWidget **temp = data;
	gtk_widget_set_sensitive (temp[0],TRUE);
	gtk_widget_set_sensitive (temp[1],FALSE);

	printf("stop\n");

}




static void destroy(GtkWidget *window, gpointer data)
{
	    printf("Terminate Program\n");
		sprintf((char *)shm_addr,"%d",-1);
		gtk_main_quit();

}

/*Return FALSE to destroy the widget. By returning TRUE, you can cancel a delete-event. This can be used to confirm quitting the application*/
static gboolean delete_event(GtkWidget *window , GdkEvent *evebt, gpointer data){
	    return FALSE;
}


#include<gtk/gtk.h>

typedef struct{
	GtkWidget *window;
	GtkEntry **value;
	GtkWidget *combo_box;
} change;


static void refresh_value(GtkEntry*, gpointer);
static void check_value(GtkWidget* ,change*);
static void apply_value();
static void show_error(GtkWidget*, change*);


int main(int argc, char *argv[])

{
	
	GtkWidget *window, *fixed, *combo_box, *table, *attr[10], *value[10], *btn[2];

	change *changePTR;

	int i=0;

	/* Initialize GTK */
	gtk_init(&argc,&argv);

	/* Create a new window */
	window = gtk_window_new (GTK_WINDOW_TOPLEVEL);
	gtk_widget_set_size_request(window,350,410);
	gtk_window_set_resizable(GTK_WINDOW(window),FALSE);
  gtk_window_set_title (GTK_WINDOW (window), "Ex-combobox");
	gtk_window_position  (GTK_WINDOW(window), GTK_WIN_POS_CENTER);


	/* Conect the "destroy" event to a signal handler*/
	g_signal_connect (window, "destroy", G_CALLBACK (gtk_main_quit), NULL);

	/* Sets the border width of the window. */
	gtk_container_set_border_width (GTK_CONTAINER (window), 10);

	/* Create a fixed container */
	fixed = gtk_fixed_new();
	gtk_container_add(GTK_CONTAINER (window), fixed);
	gtk_widget_show (fixed);

	/* Create a Combo_box */
	combo_box = gtk_combo_box_new_text();

	/* Set the combo_box item */
	gtk_combo_box_append_text(GTK_COMBO_BOX(combo_box),"MSVCB01");
	gtk_combo_box_append_text(GTK_COMBO_BOX(combo_box),"MSVCB02");

	/* Set the first item-active */
	gtk_combo_box_set_active(GTK_COMBO_BOX(combo_box),0);

	/* Add Combo_box to fixed container */
	gtk_fixed_put(GTK_FIXED (fixed), combo_box,0,0);

	/* Create a table */
	table = gtk_table_new(11,2,TRUE);

	/* Create a label(attr)*/
	attr[0]=gtk_label_new("MsvCBName");
	attr[1]=gtk_label_new("MsvCBRef");
	attr[2]=gtk_label_new("SvEna");
	attr[3]=gtk_label_new("MsvID");
	attr[4]=gtk_label_new("DatSet");
	attr[5]=gtk_label_new("ConfRev");
	attr[6]=gtk_label_new("SmpMod");
	attr[7]=gtk_label_new("SmpRate");
	attr[8]=gtk_label_new("OptFlds");
	attr[9]=gtk_label_new("DstAddress");

	/* Create a entry(value)*/
	for(i=0;i<10;i++)
	{
		value[i]=gtk_entry_new();
		gtk_entry_set_alignment(GTK_ENTRY(value[i]),0.5);
		gtk_entry_set_text(GTK_ENTRY(value[i]),"3");
	}

	/* Attach the label(attr) and entry(value) widget to their parent container(table)  */

	for(i=0;i<10;i++)
	{
		gtk_table_attach(GTK_TABLE(table),attr[i],0,1,i,i+1,GTK_EXPAND,GTK_SHRINK,0,0);
		gtk_table_attach(GTK_TABLE(table),value[i],1,2,i,i+1,GTK_EXPAND,GTK_SHRINK,0,0);
	}

	/* Add 5 pixels of spacing between every row and every column */
	gtk_table_set_row_spacings(GTK_TABLE(table),5);
	gtk_table_set_col_spacings(GTK_TABLE(table),5);

	/* Add Combo_box to fixed container */
	gtk_fixed_put(GTK_FIXED (fixed), table,0,40);

	/* Create a button */
	btn[0]=gtk_button_new_with_label("refresh");
	btn[1]=gtk_button_new_with_label("APPLY");

	/* Add buttons to fixed container */	
	gtk_fixed_put(GTK_FIXED (fixed), btn[0],200,360);
	gtk_fixed_put(GTK_FIXED (fixed), btn[1],270,360);

	/*Create a change structure and allocate window , value(entry), combo_box */
	changePTR = g_new(change,1);
	changePTR -> window = (GtkWidget *) window;
	changePTR -> value = (GtkEntry**) value;
	changePTR -> combo_box = (GtkWidget *) combo_box;

	/* Conect the "clicked" event to a signal handler*/
	g_signal_connect (G_OBJECT(btn[0]), "clicked", G_CALLBACK(refresh_value),(gpointer)value);
	g_signal_connect (G_OBJECT(btn[1]), "clicked", G_CALLBACK(check_value),changePTR);

	/* Display the window */
	gtk_widget_show_all(window);

	/* Enter the event loop */
	gtk_main();

	return 0;
}

/* clear all values when user click 'refresh' button */
static void refresh_value(GtkEntry *Entry, gpointer data)
{
	GtkEntry **entry = (GtkEntry**)data;
	int k;
//	printf("click refresh\n");
	
	for(k=0;k<10;k++)
	{
		gtk_entry_set_text(GTK_ENTRY(entry[k]),"");
	}
	
}

/* check all values when user click 'apply' button */
static void check_value(GtkWidget *window, change *change)
{
	GtkWidget *w = change->window;
	GtkEntry **entry = change->value;
	GtkWidget *combo_box = change->combo_box;

	int k;
	int chk=1;

	for(k=0;k<10;k++)
	{
		if(strcmp("",gtk_entry_get_text(GTK_ENTRY(entry[k])))==0)
		{
			show_error(window,change);
			chk=0;
			break;
		}
	}
	
	if(chk==1)
	{
		if(gtk_combo_box_get_active(GTK_COMBO_BOX(combo_box))==0)
		{
			printf("you select : MSVCB01\n");
		}else
		{
			printf("you select : MSVCB02\n");
		}
	}
	
	/* fill in code to submit value to SISCO code(use shared memory) */

	
}

/* Show error dialog */
static void show_error(GtkWidget *window, change *change)
{
	GtkWidget *w = change->window;
	GtkWidget *dialog;
	dialog = gtk_message_dialog_new(GTK_WINDOW(w),GTK_DIALOG_DESTROY_WITH_PARENT, GTK_MESSAGE_ERROR,GTK_BUTTONS_OK, "Please fill in all values");
	gtk_window_set_title(GTK_WINDOW(dialog),"Error");
	gtk_dialog_run(GTK_DIALOG(dialog));
	gtk_widget_destroy(dialog);
}

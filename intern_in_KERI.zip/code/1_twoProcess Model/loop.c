#include<stdio.h>
#include<unistd.h>
#include<string.h>
#include<sys/ipc.h>
#include<sys/shm.h>


#define KEY_NUM	9527
#define MEM_SIZE 16

int main(void)
{

	/*Start - shared memory setting*/
	int shm_id;
	void *shm_addr;
	int count;
	char temp;

	if(-1==(shm_id=shmget((key_t)KEY_NUM,MEM_SIZE,IPC_CREAT|0666)))
	{
		printf("Fail to make a shared memory\n");
		return -1;
	}

	if((void*)-1==(shm_addr=shmat(shm_id,(void*)0,0)))
	{
		printf("Fail to attach the shared memory\n");
		return -1;
	}

	int k=0;
	/*End - Shared memory setting*/
	
	while(1){
		
		if(strcmp("-1",(char *)shm_addr)==0)
			break;
		else if(strcmp("1",(char *)shm_addr)==0)
		{
			printf("%d\n",k);
			k++;
			sleep(1);
		}else
		{
			continue;
		}

	}
	
	if(-1==shmctl(shm_id,IPC_RMID,0))
	{
		printf("SHARED MEMOEY REMOVE FAIL\n");
		return -1;
	}
	else
	{
		printf("SHARED MEMORY REMOVE SUCCESS\n");
		printf("Terminate Program\n");
		return 0;
	}
	//return 0;
}
